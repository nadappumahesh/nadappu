/*
jQuery(document).ready(function($) {
	$('input.iphonecheck').iphoneStyle({ resizeContainer: false, resizeHandle: false });
});*/
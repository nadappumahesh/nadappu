<?php

	// START Include
	error_reporting(0);
	include("admin/bdayh.php");
	if ( ! isset( $content_width ) ) $content_width = 655;
	// END Include

?>